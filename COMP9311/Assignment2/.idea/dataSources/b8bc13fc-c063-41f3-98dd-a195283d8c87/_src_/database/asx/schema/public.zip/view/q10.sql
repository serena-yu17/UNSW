CREATE VIEW q10 AS SELECT category.code,
    category.industry
   FROM category
  WHERE ((category.industry)::text IN ( SELECT category_1.industry
           FROM category category_1
          GROUP BY category_1.industry
         HAVING (count(category_1.industry) = 1)))
  ORDER BY category.code;
