CREATE VIEW q12 AS SELECT executive.person AS name
   FROM executive
  GROUP BY executive.person
 HAVING (count(executive.code) > 1)
  ORDER BY executive.person;
