CREATE VIEW q15 AS SELECT asx.code,
    min(asx.price) AS minprice,
    avg(asx.price) AS avgprice,
    max(asx.price) AS maxprice,
    min(q7.gain) AS mindaygain,
    avg(q7.gain) AS avgdaygain,
    max(q7.gain) AS maxdaygain
   FROM q7,
    asx
  WHERE (q7.code = asx.code)
  GROUP BY asx.code
  ORDER BY asx.code;
