CREATE VIEW avgcprating AS SELECT rating.code,
    avg(rating.star) AS avgcompanyrating
   FROM rating
  GROUP BY rating.code;
