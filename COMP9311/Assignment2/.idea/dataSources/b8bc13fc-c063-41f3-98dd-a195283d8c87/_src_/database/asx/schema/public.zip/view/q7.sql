CREATE VIEW q7 AS SELECT asx_late."Date",
    asx_late.code,
    asx_late.volume,
    asx_early.price AS prevprice,
    asx_late.price,
    (asx_late.price - asx_early.price) AS change,
    (((asx_late.price - asx_early.price) / asx_early.price) * (100)::numeric) AS gain
   FROM asx asx_early,
    asx asx_late
  WHERE ((asx_early.code = asx_late.code) AND (asx_early."Date" = ( SELECT max(asx_general."Date") AS max
           FROM asx asx_general
          WHERE ((asx_general."Date" < asx_late."Date") AND (asx_general.code = asx_early.code)))))
  ORDER BY asx_late."Date";
