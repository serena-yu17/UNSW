CREATE VIEW q6 AS SELECT DISTINCT company.name
   FROM (company
     JOIN category ON ((company.code = category.code)))
  WHERE (((category.sector)::text = 'Services'::text) AND ((company.country)::text = 'Australia'::text) AND ((company.zip)::text ~ '^2'::text))
  ORDER BY company.name;
