CREATE VIEW sector_gain AS SELECT category.sector,
    q7."Date",
    q7.code,
    q7.gain
   FROM category,
    q7
  WHERE ((category.code = q7.code) AND (q7."Date" = ( SELECT max(asx."Date") AS max
           FROM asx)))
  ORDER BY category.sector;
