create function q17_function() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE maxgain DOUBLE PRECISION;
        mingain DOUBLE PRECISION;
        sect    TEXT;
BEGIN

  IF (new.code IN (SELECT code -- if the company is a new one, let it use default star
                   FROM asx))
  THEN
    -- find out the sector of the company inserted
    SELECT DISTINCT category.sector
    INTO sect
    FROM category
    WHERE category.code = new.code;

    --get the max and min gains from this sector for the current day
    SELECT
      max(sector_gain.gain),
      min(sector_gain.gain)
    INTO maxgain, mingain
    FROM sector_gain
    WHERE sector_gain."Date" = new."Date"
          AND sector_gain.sector = sect;

    -- if the company is the best one(s), set 5 star
    UPDATE Rating
    SET Star = 5
    WHERE Code IN (SELECT code
                   FROM sector_gain
                   WHERE sector_gain.gain = maxgain AND sector_gain.sector = sect);

    -- if there is an even better/worse company, then the previous best/worse company is no longer the best/worse and its score needs to be reset.
    UPDATE Rating
    SET Star = 3
    WHERE Code IN (SELECT code
                   FROM sector_gain
                   WHERE sector_gain.gain != maxgain
                         AND sector_gain.gain != mingain
                         AND sector_gain.sector = sect);
    -- if the company is the worse one(s), set 1 star
    UPDATE Rating
    SET Star = 1
    WHERE Code IN (SELECT code
                   FROM sector_gain
                   WHERE sector_gain.gain = mingain AND sector_gain.sector = sect);
  END IF;
  RETURN NEW;
END;
$$;
