CREATE VIEW q13 AS SELECT company.code,
    company.name,
    company.address,
    company.zip,
    category.sector
   FROM company,
    category
  WHERE ((company.code = category.code) AND ((company.country)::text = 'Australia'::text) AND (NOT ((category.sector)::text IN ( SELECT category_1.sector
           FROM category category_1,
            company company_1
          WHERE ((company_1.code = category_1.code) AND ((company_1.country)::text <> 'Australia'::text))))))
  ORDER BY company.code;
