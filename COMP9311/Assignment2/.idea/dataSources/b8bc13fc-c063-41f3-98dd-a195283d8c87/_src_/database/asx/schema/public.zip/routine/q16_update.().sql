create function q16_update() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (new.Person != old.person AND
      new.person IN (
        SELECT Person
        FROM Executive
        GROUP BY Person -- If one of the companies have its executive changed to
        HAVING COUNT(Code) > 0))    -- a person who is already an executive of a company
  THEN
    RAISE EXCEPTION 'This person is already an executive of another company.';
  ELSE
    RETURN new;
  END IF;
END;
$$;
