CREATE VIEW q14 AS SELECT asx_first.code,
    asx_first.price AS beginprice,
    asx_end.price AS endprice,
    (asx_end.price - asx_first.price) AS change,
    (((asx_end.price - asx_first.price) / asx_first.price) * (100)::numeric) AS gain
   FROM asx asx_first,
    asx asx_end
  WHERE ((asx_first.code = asx_end.code) AND (asx_first."Date" = ( SELECT min(asx."Date") AS min
           FROM asx)) AND (asx_end."Date" = ( SELECT max(asx."Date") AS max
           FROM asx)))
  ORDER BY (((asx_end.price - asx_first.price) / asx_first.price) * (100)::numeric) DESC, asx_first.code;
