CREATE VIEW q3 AS SELECT DISTINCT company.name
   FROM company,
    category
  WHERE ((company.code = category.code) AND ((category.sector)::text = 'Technology'::text))
  ORDER BY company.name;
