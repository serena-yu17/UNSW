CREATE VIEW q4 AS SELECT category.sector,
    count(DISTINCT category.industry) AS number
   FROM category
  GROUP BY category.sector
  ORDER BY category.sector;
