CREATE VIEW q1 AS SELECT company.name,
    company.country
   FROM company
  WHERE ((company.country)::text <> 'Australia'::text)
  ORDER BY company.name;
