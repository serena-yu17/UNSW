create function q16_insert() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (new.Person IN (
    SELECT Person
    FROM Executive
    GROUP BY Person --If the person inserted is already an executive of a company
    HAVING COUNT(Code) > 0))
  THEN
    RAISE EXCEPTION 'This person is already an executive of another company.';
  ELSE
    RETURN new;
  END IF;
END;
$$;
