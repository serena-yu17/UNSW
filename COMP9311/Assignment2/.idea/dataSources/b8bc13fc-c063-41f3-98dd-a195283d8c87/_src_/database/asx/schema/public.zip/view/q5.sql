CREATE VIEW q5 AS SELECT DISTINCT executive.person AS name
   FROM (executive
     JOIN category ON ((executive.code = category.code)))
  WHERE ((category.sector)::text = 'Technology'::text)
  ORDER BY executive.person;
