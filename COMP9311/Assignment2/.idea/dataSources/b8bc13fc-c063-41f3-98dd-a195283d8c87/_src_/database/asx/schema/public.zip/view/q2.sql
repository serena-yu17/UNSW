CREATE VIEW q2 AS SELECT executive.code
   FROM executive
  GROUP BY executive.code
 HAVING (count(executive.code) > 5)
  ORDER BY executive.code;
