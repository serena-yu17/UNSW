create function q18_function() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (NEW."Date" = OLD."Date" AND OLD.Code = NEW.Code)
  THEN -- do the logging
    INSERT INTO ASXLog ("Timestamp", Code, "Date", OldVolume, OldPrice)
    VALUES (CURRENT_TIMESTAMP, OLD.Code, OLD."Date", OLD.Volume, OLD.Price);
  ELSE --we assume that Date and Code cannot be corrected and will be the same as their original
    RAISE EXCEPTION 'The Date and Code must not be corrected.';
  END IF;
  RETURN NEW;
END;
$$;
