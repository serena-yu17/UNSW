CREATE VIEW q8 AS SELECT asx_day."Date",
    asx_day.code,
    asx_day.volume
   FROM asx asx_day
  WHERE (asx_day.volume = ( SELECT max(asx_all.volume) AS max
           FROM asx asx_all
          WHERE (asx_all."Date" = asx_day."Date")))
  ORDER BY asx_day."Date", asx_day.code;
