CREATE VIEW q9 AS SELECT category.sector,
    category.industry,
    count(category.code) AS number
   FROM category
  GROUP BY category.sector, category.industry
  ORDER BY category.sector, category.industry;
