CREATE VIEW q11 AS SELECT category.sector,
    avg(avgcprating.avgcompanyrating) AS avgrating
   FROM category,
    avgcprating
  WHERE (category.code = avgcprating.code)
  GROUP BY category.sector
  ORDER BY (avg(avgcprating.avgcompanyrating)) DESC, category.sector;
