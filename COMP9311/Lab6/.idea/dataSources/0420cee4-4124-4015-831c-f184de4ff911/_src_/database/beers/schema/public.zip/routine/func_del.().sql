create function func_del() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE beer
  SET totrating = totRating - old.score
  WHERE beer.id = old.beer;

  UPDATE beer
  SET nRatings = nRatings - 1
  WHERE beer.id = old.beer;

  UPDATE beer
  SET rating = totrating / nRatings
  WHERE beer.id = old.beer;

  RETURN OLD;
END;
$$;
