create function func_upd() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (NEW.score != old.score AND new.beer = old.beer)
  THEN

    UPDATE beer
    SET totrating = totRating + NEW.score - old.score
    WHERE beer.id = new.beer;

    UPDATE beer
    SET rating = totrating / nRatings
    WHERE beer.id = new.beer;

  END IF;
  RETURN NEW;
END;
$$;
