create function func_ins() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE beer
  SET totrating = totRating + NEW.score
  WHERE beer.id = new.beer;

  UPDATE beer
  SET nRatings = nRatings + 1
  WHERE beer.id = new.beer;

  UPDATE beer
  SET rating = totrating / nRatings
  WHERE beer.id = new.beer;
  RETURN NEW;
END;
$$;
