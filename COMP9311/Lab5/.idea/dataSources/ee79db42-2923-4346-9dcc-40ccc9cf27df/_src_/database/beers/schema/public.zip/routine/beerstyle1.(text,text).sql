create function beerstyle1(_brewer text, _beer text) returns text
LANGUAGE plpgsql
AS $$
DECLARE beer_name TEXT;
BEGIN
  SELECT beerstyle.name
  INTO beer_name
  FROM beerstyle, beer, brewer
  WHERE beerstyle.id = beer.style AND beer.brewer = brewer.id AND lower(beer.name) = lower(_beer) AND
        lower(brewer.name) = lower(_brewer);
  RETURN beer_name;
END;
$$;
