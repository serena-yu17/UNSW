create function favouritebeer(taster text) returns SETOF beerinfo
LANGUAGE SQL
AS $$
SELECT
  brewer.name AS brewer,
  beer.name   AS beer
FROM brewer, beer
WHERE brewer.id = beer.brewer AND beer.id = (
  SELECT beer
  FROM ratings, taster
  WHERE taster.id = ratings.taster AND taster.given = $1 AND ratings.score = (
    SELECT max(score)
    FROM ratings, taster
    WHERE taster.id = ratings.taster AND taster.given = $1
  )
);
$$;
