CREATE VIEW tastersbycountry AS SELECT location.country,
    concat((taster.given)::text) AS tasters
   FROM location,
    taster
  WHERE (location.id = taster.livesin)
  GROUP BY location.country;
