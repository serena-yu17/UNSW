create function agg_concat(text, text) returns text
LANGUAGE SQL
AS $$
SELECT CASE WHEN ($2 IS NOT NULL)
  THEN
    (SELECT CASE WHEN ($1 != '')
      THEN
        $1 || ',' || $2
            ELSE
              $2
            END)
       ELSE
         $1
       END;
$$;
