CREATE VIEW johnsfavouritebeer AS SELECT brewer.name AS brewer,
    beer.name AS beer
   FROM brewer,
    beer
  WHERE ((brewer.id = beer.brewer) AND (beer.id = ( SELECT ratings.beer
           FROM ratings,
            taster
          WHERE ((taster.id = ratings.taster) AND ((taster.given)::text = 'John'::text) AND (ratings.score = ( SELECT max(ratings_1.score) AS max
                   FROM ratings ratings_1,
                    taster taster_1
                  WHERE ((taster_1.id = ratings_1.taster) AND ((taster_1.given)::text = 'John'::text))))))));
