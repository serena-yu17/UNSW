create function beerstyle(brewer text, beer text) returns text
LANGUAGE SQL
AS $$
SELECT beerstyle.name
FROM beerstyle, beer, brewer
WHERE beerstyle.id = beer.style AND beer.brewer = brewer.id AND lower(beer.name) = lower($2) AND
      lower(brewer.name) = lower($1);
$$;
