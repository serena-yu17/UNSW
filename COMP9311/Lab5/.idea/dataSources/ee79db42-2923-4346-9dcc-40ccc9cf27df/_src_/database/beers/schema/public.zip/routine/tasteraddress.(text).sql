create function tasteraddress(taster text) returns text
LANGUAGE plpgsql
AS $$
DECLARE add_state   TEXT;
        add_country TEXT;
BEGIN
  SELECT
    loc.state,
    loc.country
  INTO add_state, add_country
  FROM Taster t, LOCATION loc
  WHERE t.given = $1 AND t.livesIn = loc.id;
  IF (add_state IS NOT NULL AND add_country IS NOT NULL)
  THEN
    RETURN add_state || ', ' || add_country;
  ELSEIF (add_state IS NOT NULL)
    THEN
      RETURN add_state;
  ELSE
    RETURN add_country;
  END IF;
END;
$$;
