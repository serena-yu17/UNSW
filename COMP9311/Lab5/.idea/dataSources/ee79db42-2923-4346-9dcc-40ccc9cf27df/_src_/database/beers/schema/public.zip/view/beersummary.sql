CREATE VIEW beersummary AS SELECT allratings.beer,
    round(avg(allratings.rating), 2) AS rating,
    concat((allratings.taster)::text) AS tasters
   FROM allratings
  GROUP BY allratings.beer;
