create function beersummary() returns text
LANGUAGE plpgsql
AS $$
DECLARE
  tex             TEXT;
  beer_name       TEXT;
  rating_score    TEXT;
  concated_taster TEXT;
  temptext        TEXT;
  cur_text        TEXT;
BEGIN
  FOR beer_name IN SELECT DISTINCT name
                   FROM beer
                   ORDER BY name LOOP
    --average rating
    SELECT cast(round(avg(score), 1) AS TEXT)
    INTO rating_score
    FROM ratings, beer
    WHERE ratings.beer = beer.id AND beer.name = beer_name;
    --concatenate tasters' names
    FOR temptext IN SELECT taster.given
                    FROM taster, ratings, beer
                    WHERE taster.id = ratings.taster AND beer.id = ratings.beer AND beer.name = beer_name LOOP
      IF (concated_taster IS NULL)
      THEN
        concated_taster := temptext;
      ELSE
        IF (temptext IS NOT NULL)
        THEN
          concated_taster := concated_taster || ', ' || temptext;
        END IF;
      END IF;
    END LOOP;
    --concatenate into output text
    cur_text:= 'beer:' || E'\t' || beer_name || E'\n' || 'Rating:' || E'\t' || rating_score || E'\n' || 'Tasters:' ||
               concated_taster || E'\n\n';
    IF (tex IS NULL)
    THEN
      tex:=cur_text;
    ELSE
      IF (cur_text IS NOT NULL)
      THEN
        tex:=
        tex || 'beer:' || E'\t' || beer_name || E'\n' || 'Rating:' || E'\t' || rating_score || E'\n' || 'Tasters:'
        || concated_taster || E'\n\n';
      END IF;
    END IF;
    concated_taster := NULL;
  END LOOP;
  RETURN tex;
END;
$$;
