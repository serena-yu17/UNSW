CREATE VIEW allratings AS SELECT taster.given AS taster,
    beer.name AS beer,
    brewer.name AS brewer,
    ratings.score AS rating
   FROM taster,
    ratings,
    beer,
    brewer
  WHERE ((ratings.beer = beer.id) AND (taster.id = ratings.taster) AND (brewer.id = beer.brewer))
  ORDER BY taster.given, beer.name;
