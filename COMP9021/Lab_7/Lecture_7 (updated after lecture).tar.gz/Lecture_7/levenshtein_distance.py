# Written by Eric Martin for COMP9021


'''
Given 2 words, creates an object which can provide the levenshtein distance
between both words, the alignments of minimal cost between both words,
and the display of those alignments.
The costs for insertion, deletion and substitution are set by default
to 1, 1 and 2, respectively, but can be changed.
'''


class Levenshtein_distance:
    '''
    Given two words word_1 and word_2, builds a table of distances
    and backtraces for the initial segments of word_1 and word_2,
    from which the Levenshtein distance between both words can be computed,
    as well as the possible alignments of minimal distance between
    both words.
    '''
    def __init__(self, word_1, word_2, insertion_cost = 1, deletion_cost = 1, substitution_cost = 2
                ):
        self.word_1 = word_1
        self.word_2 = word_2
        self.word_1_length = len(word_1)
        self.word_2_length = len(word_2)
        self.insertion_cost = insertion_cost
        self.deletion_cost = deletion_cost
        self.substitution_cost = substitution_cost
        self._table = self._get_distances_and_backtraces_table()
        self._backtraces = [[self._table[i][j][1] for j in range(self.word_2_length + 1)
                            ] for i in range(self.word_1_length + 1)
                           ]
        self.aligned_pairs = self.get_aligned_pairs()
        
    def _get_distances_and_backtraces_table(self):
        N_1 = self.word_1_length + 1
        N_2 = self.word_2_length + 1
        # 'H' is for horizontal, corresponding to a deletion,
        # 'V' is for vertical, corresponding to an insertion, and
        # 'D' for diagonal, corresponding to a substitution
        d = {'H' : 0, 'V' : 0, 'D' : 0}
        # Think of table as a sequence of columns, read from left to right,
        # each column beging read from bottom to top, with word_1 and word_2
        # positioned as follows.
        #
        #  2
        #  _
        #  d
        #  r
        #  o
        #  w
        #  .
        #    . w o r d _ 1
        #
        # Each position in the sequence of columns will record the minimal
        # cost of aligning the corresponding initial segment of word_1
        # with the corresponding initial segment of word_2, and also the last
        # move -- horizontal, vertical, diagonal -- from a neighbouring
        # position -- left, below, or left and below, respectively -- that can
        # yield this minimal cost.
        table = [[[0, []] for _ in range(N_2)] for _ in range(N_1)]
        # Bottom row: cost of deleting more and more letters from word_1.
        for i in range(1, N_1):
            table[i][0] = [i, ['H']]
        # Leftmost column: cost of insertion more and more letters from word_2.
        for j in range(1, N_2):
            table[0][j] = [j, ['V']]
        # Processing all other rows from bottom to top, and each row from left to right,
        # determine the cost of each possible operation:
        # - deleting current letter (of index i-1) of word_1,
        # - inserting current letter (of index j-1) of word_2,
        # - matching or substituting currents letters of word_1 and word_2.
        for i in range(1, N_1):
            for j in range(1, N_2):
                d['H'] = table[i - 1][j][0] + self.deletion_cost
                d['V'] = table[i][j - 1][0] + self.insertion_cost
                if self.word_1[i - 1] == self.word_2[j - 1]:
                    d['D'] = table[i - 1][j - 1][0]
                else:
                    d['D'] = table[i - 1][j - 1][0] + self.substitution_cost
                # Sorting by cost, keeping track of the associated direction.
                distances_and_directions = sorted((d[x], x) for x in d)
                # Mininal cost...
                table[i][j][0] = distances_and_directions[0][0]
                # ... and its associated direction...
                table[i][j][1].append(distances_and_directions[0][1])
                # ... together with the second direction if associated cost is the same...
                if distances_and_directions[1][0] == distances_and_directions[0][0]:
                    table[i][j][1].append(distances_and_directions[1][1])
                    # ... together with the third direction if associated cost is the same.
                    if distances_and_directions[2][0] == distances_and_directions[1][0]:
                        table[i][j][1].append(distances_and_directions[2][1])
        return table
    
    # We start at the top right corner of _backtraces, where we find
    # the last directions taken to get there at minimal cost,
    # and move backwards all the way to the bottom left corner,
    # eventually generating all paths from the bottom left corner
    # to the top right corner that yield that minimal cost.
    def _compute_alignments(self, i, j):
        if i == j == 0:
            yield ('', '')
        for direction in self._backtraces[i][j]:
            if direction == 'H':
                deletion_pairs = self._compute_alignments(i - 1, j)               
                yield from ((pair[0] + self.word_1[i - 1], pair[1] + '*')
                                                                          for pair in deletion_pairs
                           )
            elif direction == 'V':
                insertion_pairs = self._compute_alignments(i, j - 1)
                yield from ((pair[0] + '*', pair[1] + self.word_2[j - 1])
                                                                         for pair in insertion_pairs
                           )
            else:
                substitution_pairs = self._compute_alignments(i - 1, j - 1)
                yield from ((pair[0] + self.word_1[i - 1], pair[1] + self.word_2[j - 1])
                                                                      for pair in substitution_pairs
                           )
        
    def distance(self):
        '''
        Returns the Levenshtein distance equal to the minimum number
        of deletions, insertions and substitutions needed to transform
        the first word into the second word, with deletions and insertions
        incurring a cost of 1, and substitutions incurring a cost of 2.

        >>> Levenshtein_distance('', '').distance()
        0

        >>> Levenshtein_distance('abcde', '').distance()
        5

        >>> Levenshtein_distance('', 'abcde').distance()
        5

        >>> Levenshtein_distance('a', 'a').distance()
        0

        >>> Levenshtein_distance('a', 'b').distance()
        2
        
        >>> Levenshtein_distance('aa', 'a').distance()
        1
        
        >>> Levenshtein_distance('paris', 'london').distance()
        11
        
        >>> Levenshtein_distance('paper', 'pope').distance()
        3
        
        >>> Levenshtein_distance('depart', 'leopard').distance()
        5
        '''
        return self._table[self.word_1_length][self.word_2_length][0]

    def get_aligned_pairs(self):
        '''
        Returns the list of all possible ways to transform the first word
        into the second word and minimising the Levenshtein distance.
        
        >>> Levenshtein_distance('', '').get_aligned_pairs()
        [('', '')]

        >>> Levenshtein_distance('abcde', '').get_aligned_pairs()
        [('abcde', '*****')]
        
        >>> Levenshtein_distance('', 'abcde').get_aligned_pairs()
        [('*****', 'abcde')]

        >>> Levenshtein_distance('a', 'a').get_aligned_pairs()
        [('a', 'a')]

        >>> Levenshtein_distance('a', 'b').get_aligned_pairs()
        [('a', 'b'), ('*a', 'b*'), ('a*', '*b')]

        >>> Levenshtein_distance('aa', 'a').get_aligned_pairs()
        [('aa', '*a'), ('aa', 'a*')]

        >>> Levenshtein_distance('paper', 'pope').get_aligned_pairs()
        [('paper', 'pope*'), ('p*aper', 'po*pe*'), ('pa*per', 'p*ope*')]
        
        >>> len(Levenshtein_distance('paris', 'london').get_aligned_pairs())
        3653
        '''
        return [pair for pair in self._compute_alignments(self.word_1_length, self.word_2_length)]
    
    def display_all_aligned_pairs(self):
        '''
        Displays all possible ways to transform the first word
        into the second word and minimising the Levenshtein distance.

        >>> Levenshtein_distance('depart', 'leopard').display_all_aligned_pairs()
        de*part
        leopard
        <BLANKLINE>
        *de*part
        l*eopard
        <BLANKLINE>
        d*e*part
        *leopard
        <BLANKLINE>
        de*par*t
        leopard*
        <BLANKLINE>
        *de*par*t
        l*eopard*
        <BLANKLINE>
        d*e*par*t
        *leopard*
        <BLANKLINE>
        de*part*
        leopar*d
        <BLANKLINE>
        *de*part*
        l*eopar*d
        <BLANKLINE>
        d*e*part*
        *leopar*d
        '''
        print('\n\n'.join('\n'.join((pair[0], pair[1])) for pair in self.aligned_pairs))

    
if __name__ == '__main__':
    import doctest
    doctest.testmod()
